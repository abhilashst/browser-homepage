-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 01, 2005 at 08:32 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `smarthome`
--

-- --------------------------------------------------------

--
-- Table structure for table `sh_iconurlcategory`
--

CREATE TABLE IF NOT EXISTS `sh_iconurlcategory` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `status` enum('active','deactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `sh_iconurlcategory`
--

INSERT INTO `sh_iconurlcategory` (`id`, `name`, `key`, `status`) VALUES
(1, 'Search', '', 'active'),
(2, ' Social Networks', '', 'active'),
(3, 'Videos', '', 'active'),
(4, 'Music', '', 'active'),
(5, 'Cloud', '', 'active'),
(6, 'Shopping', '', 'active'),
(7, 'News', '', 'active'),
(8, 'Images', '', 'active'),
(9, 'Classifieds ', '', 'active'),
(10, 'Reference', '', 'active'),
(11, 'Business', '', 'active'),
(12, 'Navigation', '', 'active'),
(13, 'Downloads', '', 'active'),
(14, 'Jobs', '', 'active'),
(15, 'Mails', '', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sh_mainiconimages`
--

CREATE TABLE IF NOT EXISTS `sh_mainiconimages` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `very_small` varchar(255) NOT NULL,
  `small` varchar(255) NOT NULL,
  `large` varchar(255) NOT NULL,
  `launchpad_url` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL DEFAULT '1',
  `status` enum('active','deactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `sh_mainiconimages`
--

INSERT INTO `sh_mainiconimages` (`id`, `key`, `very_small`, `small`, `large`, `launchpad_url`, `user_id`, `status`) VALUES
(1, '', 'icon_images/very_small/abcnews.png', 'icon_images/small/abcnews.png', 'icon_images/large/abcnews.png', 'icon_images/launchpad/abcnews.png', '1', 'active'),
(2, '', 'icon_images/very_small/amazon.png', 'icon_images/small/amazon.png', 'icon_images/large/amazon.png', 'icon_images/launchpad/amazon.png', '1', 'active'),
(3, '', 'icon_images/very_small/aol.png', 'icon_images/small/aol.png', 'icon_images/large/aol.png', 'icon_images/launchpad/aol.png', '1', 'active'),
(4, '', 'icon_images/very_small/ask.png', 'icon_images/small/ask.png', 'icon_images/large/ask.png', 'icon_images/launchpad/ask.png', '1', 'active'),
(5, '', 'icon_images/very_small/badoo.png', 'icon_images/small/badoo.png', 'icon_images/large/badoo.png', 'icon_images/launchpad/badoo.png', '1', 'active'),
(6, '', 'icon_images/very_small/bbc.png', 'icon_images/small/bbc.png', 'icon_images/large/bbc.png', 'icon_images/launchpad/bbc.png', '1', 'active'),
(7, '', 'icon_images/very_small/bing.png', 'icon_images/small/bing.png', 'icon_images/large/bing.png', 'icon_images/launchpad/bing.png', '1', 'active'),
(8, '', 'icon_images/very_small/blekko.png', 'icon_images/small/blekko.png', 'icon_images/large/blekko.png', 'icon_images/launchpad/blekko.png', '1', 'active'),
(9, '', 'icon_images/very_small/blip.png', 'icon_images/small/blip.png', 'icon_images/large/blip.png', 'icon_images/launchpad/blip.png', '1', 'active'),
(10, '', 'icon_images/very_small/blogger.png', 'icon_images/small/blogger.png', 'icon_images/large/blogger.png', 'icon_images/launchpad/blogger.png', '1', 'active'),
(11, '', 'icon_images/very_small/chrome.png', 'icon_images/small/chrome.png', 'icon_images/large/chrome.png', 'icon_images/launchpad/chrome.png', '1', 'active'),
(12, '', 'icon_images/very_small/cnn.png', 'icon_images/small/cnn.png', 'icon_images/large/cnn.png', 'icon_images/launchpad/cnn.png', '1', 'active'),
(13, '', 'icon_images/very_small/dailymotion.png', 'icon_images/small/dailymotion.png', 'icon_images/large/dailymotion.png', 'icon_images/launchpad/dailymotion.png', '1', 'active'),
(14, '', 'icon_images/very_small/deepika.png', 'icon_images/small/deepika.png', 'icon_images/large/deepika.png', 'icon_images/launchpad/deepika.png', '1', 'active'),
(15, '', 'icon_images/very_small/dropbox.png', 'icon_images/small/dropbox.png', 'icon_images/large/dropbox.png', 'icon_images/launchpad/dropbox.png', '1', 'active'),
(16, '', 'icon_images/very_small/drudgereport.png', 'icon_images/small/drudgereport.png', 'icon_images/large/drudgereport.png', 'icon_images/launchpad/drudgereport.png', '1', 'active'),
(17, '', 'icon_images/very_small/ebay.png', 'icon_images/small/ebay.png', 'icon_images/large/ebay.png', 'icon_images/launchpad/ebay.png', '1', 'active'),
(18, '', 'icon_images/very_small/facebook.png', 'icon_images/small/facebook.png', 'icon_images/large/facebook.png', 'icon_images/launchpad/facebook.png', '1', 'active'),
(19, '', 'icon_images/very_small/flickr.png', 'icon_images/small/flickr.png', 'icon_images/large/flickr.png', 'icon_images/launchpad/flickr.png', '1', 'active'),
(20, '', 'icon_images/very_small/flipkart.png', 'icon_images/small/flipkart.png', 'icon_images/large/flipkart.png', 'icon_images/launchpad/flipkart.png', '1', 'active'),
(21, '', 'icon_images/very_small/foxnews.png', 'icon_images/small/foxnews.png', 'icon_images/large/foxnews.png', 'icon_images/launchpad/foxnews.png', '1', 'active'),
(22, '', 'icon_images/very_small/gmail.png', 'icon_images/small/gmail.png', 'icon_images/large/gmail.png', 'icon_images/launchpad/gmail.png', '1', 'active'),
(23, '', 'icon_images/very_small/goodsearch.png', 'icon_images/small/goodsearch.png', 'icon_images/large/goodsearch.png', 'icon_images/launchpad/goodsearch.png', '1', 'active'),
(24, '', 'icon_images/very_small/google.png', 'icon_images/small/google.png', 'icon_images/large/google.png', 'icon_images/launchpad/google.png', '1', 'active'),
(25, '', 'icon_images/very_small/googlemaps.png', 'icon_images/small/googlemaps.png', 'icon_images/large/googlemaps.png', 'icon_images/launchpad/googlemaps.png', '1', 'active'),
(26, '', 'icon_images/very_small/googleplus.png', 'icon_images/small/googleplus.png', 'icon_images/large/googleplus.png', 'icon_images/launchpad/googleplus.png', '1', 'active'),
(27, '', 'icon_images/very_small/huffingtonpost.png', 'icon_images/small/huffingtonpost.png', 'icon_images/large/huffingtonpost.png', 'icon_images/launchpad/huffingtonpost.png', '1', 'active'),
(28, '', 'icon_images/very_small/icloud.png', 'icon_images/small/icloud.png', 'icon_images/large/icloud.png', 'icon_images/launchpad/icloud.png', '1', 'active'),
(29, '', 'icon_images/very_small/idrive.png', 'icon_images/small/idrive.png', 'icon_images/large/idrive.png', 'icon_images/launchpad/idrive.png', '1', 'active'),
(30, '', 'icon_images/very_small/imdb.png', 'icon_images/small/imdb.png', 'icon_images/large/imdb.png', 'icon_images/launchpad/imdb.png', '1', 'active'),
(31, '', 'icon_images/very_small/itunes.png', 'icon_images/small/itunes.png', 'icon_images/large/itunes.png', 'icon_images/launchpad/itunes.png', '1', 'active'),
(32, '', 'icon_images/very_small/keralakaumudi.png', 'icon_images/small/keralakaumudi.png', 'icon_images/large/keralakaumudi.png', 'icon_images/launchpad/keralakaumudi.png', '1', 'active'),
(33, '', 'icon_images/very_small/lastfm.png', 'icon_images/small/lastfm.png', 'icon_images/large/lastfm.png', 'icon_images/launchpad/lastfm.png', '1', 'active'),
(34, '', 'icon_images/very_small/latimes.png', 'icon_images/small/latimes.png', 'icon_images/large/latimes.png', 'icon_images/launchpad/latimes.png', '1', 'active'),
(35, '', 'icon_images/very_small/linkedin.png', 'icon_images/small/linkedin.png', 'icon_images/large/linkedin.png', 'icon_images/launchpad/linkedin.png', '1', 'active'),
(36, '', 'icon_images/very_small/madhyamam.png', 'icon_images/small/madhyamam.png', 'icon_images/large/madhyamam.png', 'icon_images/launchpad/madhyamam.png', '1', 'active'),
(37, '', 'icon_images/very_small/mangalam.png', 'icon_images/small/mangalam.png', 'icon_images/large/mangalam.png', 'icon_images/launchpad/mangalam.png', '1', 'active'),
(38, '', 'icon_images/very_small/manorama.png', 'icon_images/small/manorama.png', 'icon_images/large/manorama.png', 'icon_images/launchpad/manorama.png', '1', 'active'),
(39, '', 'icon_images/very_small/mathrubhumi.png', 'icon_images/small/mathrubhumi.png', 'icon_images/large/mathrubhumi.png', 'icon_images/launchpad/mathrubhumi.png', '1', 'active'),
(40, '', 'icon_images/very_small/monster.png', 'icon_images/small/monster.png', 'icon_images/large/monster.png', 'icon_images/launchpad/monster.png', '1', 'active'),
(41, '', 'icon_images/very_small/mozilla.png', 'icon_images/small/mozilla.png', 'icon_images/large/mozilla.png', 'icon_images/launchpad/mozilla.png', '1', 'active'),
(42, '', 'icon_images/very_small/mp3skull.png', 'icon_images/small/mp3skull.png', 'icon_images/large/mp3skull.png', 'icon_images/launchpad/mp3skull.png', '1', 'active'),
(43, '', 'icon_images/very_small/msn.png', 'icon_images/small/msn.png', 'icon_images/large/msn.png', 'icon_images/launchpad/msn.png', '1', 'active'),
(44, '', 'icon_images/very_small/mtorrent.png', 'icon_images/small/mtorrent.png', 'icon_images/large/mtorrent.png', 'icon_images/launchpad/mtorrent.png', '1', 'active'),
(45, '', 'icon_images/very_small/mysyncplicity.png', 'icon_images/small/mysyncplicity.png', 'icon_images/large/mysyncplicity.png', 'icon_images/launchpad/mysyncplicity.png', '1', 'active'),
(46, '', 'icon_images/very_small/myspace.png', 'icon_images/small/myspace.png', 'icon_images/large/myspace.png', 'icon_images/launchpad/myspace.png', '1', 'active'),
(47, '', 'icon_images/very_small/nbc.png', 'icon_images/small/nbc.png', 'icon_images/large/nbc.png', 'icon_images/launchpad/nbc.png', '1', 'active'),
(48, '', 'icon_images/very_small/newyork.png', 'icon_images/small/newyork.png', 'icon_images/large/newyork.png', 'icon_images/launchpad/newyork.png', '1', 'active'),
(49, '', 'icon_images/very_small/opendrive.png', 'icon_images/small/opendrive.png', 'icon_images/large/opendrive.png', 'icon_images/launchpad/opendrive.png', '1', 'active'),
(50, '', 'icon_images/very_small/orkut.png', 'icon_images/small/orkut.png', 'icon_images/large/orkut.png', 'icon_images/launchpad/orkut.png', '1', 'active'),
(51, '', 'icon_images/very_small/pandoramusic.png', 'icon_images/small/pandoramusic.png', 'icon_images/large/pandoramusic.png', 'icon_images/launchpad/pandoramusic.png', '1', 'active'),
(52, '', 'icon_images/very_small/picasa.png', 'icon_images/small/picasa.png', 'icon_images/large/picasa.png', 'icon_images/launchpad/picasa.png', '1', 'active'),
(53, '', 'icon_images/very_small/scribd.png', 'icon_images/small/scribd.png', 'icon_images/large/scribd.png', 'icon_images/launchpad/scribd.png', '1', 'active'),
(54, '', 'icon_images/very_small/snapdeal.png', 'icon_images/small/snapdeal.png', 'icon_images/large/snapdeal.png', 'icon_images/launchpad/snapdeal.png', '1', 'active'),
(55, '', 'icon_images/very_small/songspk.png', 'icon_images/small/songspk.png', 'icon_images/large/songspk.png', 'icon_images/launchpad/songspk.png', '1', 'active'),
(56, '', 'icon_images/very_small/spideroak.png', 'icon_images/small/spideroak.png', 'icon_images/large/spideroak.png', 'icon_images/launchpad/spideroak.png', '1', 'active'),
(57, '', 'icon_images/very_small/sugarsync.png', 'icon_images/small/sugarsync.png', 'icon_images/large/sugarsync.png', 'icon_images/launchpad/sugarsync.png', '1', 'active'),
(58, '', 'icon_images/very_small/teamdrive.png', 'icon_images/small/teamdrive.png', 'icon_images/large/teamdrive.png', 'icon_images/launchpad/teamdrive.png', '1', 'active'),
(59, '', 'icon_images/very_small/thehindu.png', 'icon_images/small/thehindu.png', 'icon_images/large/thehindu.png', 'icon_images/launchpad/thehindu.png', '1', 'active'),
(60, '', 'icon_images/very_small/timesofindia.png', 'icon_images/small/timesofindia.png', 'icon_images/large/timesofindia.png', 'icon_images/launchpad/timesofindia.png', '1', 'active'),
(61, '', 'icon_images/very_small/twitter.png', 'icon_images/small/twitter.png', 'icon_images/large/twitter.png', 'icon_images/launchpad/twitter.png', '1', 'active'),
(62, '', 'icon_images/very_small/ubuntuone.png', 'icon_images/small/ubuntuone.png', 'icon_images/large/ubuntuone.png', 'icon_images/launchpad/ubuntuone.png', '1', 'active'),
(63, '', 'icon_images/very_small/viddler.png', 'icon_images/small/viddler.png', 'icon_images/large/viddler.png', 'icon_images/launchpad/viddler.png', '1', 'active'),
(64, '', 'icon_images/very_small/washingtonpost.png', 'icon_images/small/washingtonpost.png', 'icon_images/large/washingtonpost.png', 'icon_images/launchpad/washingtonpost.png', '1', 'active'),
(65, '', 'icon_images/very_small/weatherchannel.png', 'icon_images/small/weatherchannel.png', 'icon_images/large/weatherchannel.png', 'icon_images/launchpad/weatherchannel.png', '1', 'active'),
(66, '', 'icon_images/very_small/wikipedia.png', 'icon_images/small/wikipedia.png', 'icon_images/large/wikipedia.png', 'icon_images/launchpad/wikipedia.png', '1', 'active'),
(67, '', 'icon_images/very_small/windowslive.png', 'icon_images/small/windowslive.png', 'icon_images/large/windowslive.png', 'icon_images/launchpad/windowslive.png', '1', 'active'),
(68, '', 'icon_images/very_small/worldreport.png', 'icon_images/small/worldreport.png', 'icon_images/large/worldreport.png', 'icon_images/launchpad/worldreport.png', '1', 'active'),
(69, '', 'icon_images/very_small/yahoo.png', 'icon_images/small/yahoo.png', 'icon_images/large/yahoo.png', 'icon_images/launchpad/yahoo.png', '1', 'active'),
(70, '', 'icon_images/very_small/ymusic.png', 'icon_images/small/ymusic.png', 'icon_images/large/ymusic.png', 'icon_images/launchpad/ymusic.png', '1', 'active'),
(71, '', 'icon_images/very_small/youtube.png', 'icon_images/small/youtube.png', 'icon_images/large/youtube.png', 'icon_images/launchpad/youtube.png', '1', 'active'),
(72, '', 'icon_images/very_small/yscreen.png', 'icon_images/small/yscreen.png', 'icon_images/large/yscreen.png', 'icon_images/launchpad/yscreen.png', '1', 'active'),
(73, '', 'icon_images/very_small/yuvog.png', 'icon_images/small/yuvog.png', 'icon_images/large/yuvog.png', 'icon_images/launchpad/yuvog.png', '1', 'active'),
(74, '', 'icon_images/very_small/zumodrive.png', 'icon_images/small/zumodrive.png', 'icon_images/large/zumodrive.png', 'icon_images/launchpad/zumodrive.png', '1', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sh_mainiconlist`
--

CREATE TABLE IF NOT EXISTS `sh_mainiconlist` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `icon_item_key` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `image_id` mediumint(8) NOT NULL,
  `category_id` mediumint(8) NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '1',
  `popularity_count` mediumint(8) NOT NULL,
  `status` enum('public','private','burned') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `sh_mainiconlist`
--

INSERT INTO `sh_mainiconlist` (`id`, `name`, `icon_item_key`, `url`, `image_id`, `category_id`, `user_id`, `popularity_count`, `status`) VALUES
(1, 'abcnews', '', 'http://www.abcnews.go.com', 1, 7, 1, 0, 'public'),
(2, 'amazon', '', 'http://www.amazon.com', 2, 6, 1, 0, 'public'),
(3, 'aol', '', 'http://www.aol.com', 3, 7, 1, 0, 'public'),
(4, 'ask', '', 'http://www.ask.com', 4, 1, 1, 0, 'public'),
(5, 'badoo', '', 'http://www.badoo.com', 5, 2, 1, 0, 'public'),
(6, 'bbc', '', 'http://www.bbc.com', 6, 7, 1, 0, 'public'),
(7, 'bing', '', 'http://www.bing.com', 7, 1, 1, 0, 'public'),
(8, 'blekko', '', 'http://www.blekko.com', 8, 1, 1, 0, 'public'),
(9, 'blip', '', 'http://www.blip.tv', 9, 3, 1, 0, 'public'),
(10, 'blogger', '', 'http://www.blogger.com', 10, 2, 1, 0, 'public'),
(11, 'cnn', '', 'http://www.cnn.com', 12, 7, 1, 0, 'public'),
(12, 'dailymotion', '', 'http://www.dailymotion.com/in', 13, 3, 1, 0, 'public'),
(13, 'deepika', '', 'http://www.malayalam.deepikaglobal.com', 14, 7, 1, 0, 'public'),
(14, 'dropbox', '', 'http://www.dropbox.com', 15, 5, 1, 0, 'public'),
(15, 'drudgereport', '', 'http://www.drudgereport.com', 16, 7, 1, 0, 'public'),
(16, 'ebay', '', 'http://www.ebay.in', 17, 6, 1, 0, 'public'),
(17, 'facebook', '', 'http://www.facebook.com', 18, 2, 1, 0, 'public'),
(18, 'flickr', '', 'http://www.flickr.com', 19, 8, 1, 0, 'public'),
(19, 'flipkart', '', 'http://www.flipkart.com', 20, 6, 1, 0, 'public'),
(20, 'foxnews', '', 'http://www.foxnews.com', 21, 7, 1, 0, 'public'),
(21, 'gmail', '', 'http://www.mail.google.com', 22, 15, 1, 0, 'public'),
(22, 'goodsearch', '', 'http://www.goodsearch.com', 23, 1, 1, 0, 'public'),
(23, 'google', '', 'http://www.google.com', 24, 1, 1, 0, 'public'),
(24, 'googlemaps', '', 'http://www.maps.google.com', 25, 12, 1, 0, 'public'),
(25, 'googleplus', '', 'http://www.plus.google.com', 26, 2, 1, 0, 'public'),
(26, 'huffingtonpost', '', 'http://www.huffingtonpost.com', 27, 7, 1, 0, 'public'),
(27, 'icloud', '', 'http://www.icloud.com', 28, 5, 1, 0, 'public'),
(28, 'idrive', '', 'http://www.idrive.com', 29, 5, 1, 0, 'public'),
(29, 'imdb', '', 'http://www.imdb.com', 30, 10, 1, 0, 'public'),
(30, 'itunes', '', 'http://www.apple.com/itunes', 31, 13, 1, 0, 'public'),
(31, 'keralakaumudi', '', 'http://www.keralakaumudi.com', 32, 7, 1, 0, 'public'),
(32, 'lastfm', '', 'http://www.last.fm', 33, 4, 1, 0, 'public'),
(33, 'latimes', '', 'http://www.latimes.com', 34, 7, 1, 0, 'public'),
(34, 'linkedin', '', 'http://www.linkedin.com', 35, 2, 1, 0, 'public'),
(35, 'madhyamam', '', 'http://www.madhyamam.com', 36, 7, 1, 0, 'public'),
(36, 'mangalam', '', 'http://www.mangalam.com', 37, 7, 1, 0, 'public'),
(37, 'manorama', '', 'http://www.manoramaonline.com', 38, 7, 1, 0, 'public'),
(38, 'mathrubhumi', '', 'http://www.mathrubhumi.com', 39, 7, 1, 0, 'public'),
(39, 'monster', '', 'http://www.monsterindia.com', 40, 14, 1, 0, 'public'),
(40, 'mp3skull', '', 'http://www.mp3skull.com', 42, 4, 1, 0, 'public'),
(41, 'msn', '', 'http://www.in.msn.com', 43, 7, 1, 0, 'public'),
(42, 'utorrent', '', 'http://www.utorrent.com', 44, 13, 1, 0, 'public'),
(43, 'mysyncplicity', '', 'http://www.my.syncplicity.com', 45, 5, 1, 0, 'public'),
(44, 'myspace', '', 'http://www.myspace.com', 46, 2, 1, 0, 'public'),
(45, 'nbc', '', 'http://www.nbc.com', 47, 7, 1, 0, 'public'),
(46, 'newyorktimes', '', 'http://www.nytimes.com', 48, 7, 1, 0, 'public'),
(47, 'opendrive', '', 'http://www.opendrive.com', 49, 5, 1, 0, 'public'),
(48, 'orkut', '', 'http://www.orkut.com', 50, 2, 1, 0, 'public'),
(49, 'picasa', '', 'http://www.picasaweb.google.com', 52, 8, 1, 0, 'public'),
(50, 'scribd', '', 'http://www.scribd.com', 53, 10, 1, 0, 'public'),
(51, 'snapdeal', '', 'http://www.snapdeal.com', 54, 6, 1, 0, 'public'),
(52, 'songspk', '', 'http://www.songspk.pk', 55, 4, 1, 0, 'public'),
(53, 'spideroak', '', 'http://www.spideroak.com', 56, 5, 1, 0, 'public'),
(54, 'sugarsync', '', 'http://www.sugarsync.com', 57, 5, 1, 0, 'public'),
(55, 'teamdrive', '', 'http://www.teamdrive.com', 58, 5, 1, 0, 'public'),
(56, 'thehindu', '', 'http://www.thehindu.com', 59, 7, 1, 0, 'public'),
(57, 'timesofindia', '', 'http://www.timesofindia.indiatimes.com', 60, 7, 1, 0, 'public'),
(58, 'twitter', '', 'http://www.twitter.com', 61, 2, 1, 0, 'public'),
(59, 'ubuntuone', '', 'http://www.one.ubuntu.com', 62, 5, 1, 0, 'public'),
(60, 'viddler', '', 'http://www.viddler.com', 63, 3, 1, 0, 'public'),
(61, 'washingtonpost', '', 'http://www.washingtonpost.com', 64, 7, 1, 0, 'public'),
(62, 'weatherchannel', '', 'http://www.in.weather.com', 65, 7, 1, 0, 'public'),
(63, 'wikipedia', '', 'http://www.wikipedia.org', 66, 10, 1, 0, 'public'),
(64, 'yahoo', '', 'http://www.yahoo.com', 69, 1, 1, 0, 'public'),
(65, 'ymusic', '', 'http://www.music.yahoo.com', 70, 4, 1, 0, 'public'),
(66, 'youtube', '', 'http://www.youtube.com', 71, 3, 1, 0, 'public'),
(67, 'yscreen', '', 'http://www.screen.yahoo.com', 72, 3, 1, 0, 'public'),
(68, 'yuvog', '', 'http://www.yuvog.com', 73, 3, 1, 0, 'public'),
(69, 'zumodrive', '', 'http://www.zumodrive.com', 74, 5, 1, 0, 'public');

-- --------------------------------------------------------

--
-- Table structure for table `sh_user`
--

CREATE TABLE IF NOT EXISTS `sh_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `key` varchar(255) NOT NULL,
  `createdtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('admin','normal','pending','active','deactive') NOT NULL DEFAULT 'deactive',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_n` (`username`),
  UNIQUE KEY `user_e` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `sh_user`
--

INSERT INTO `sh_user` (`id`, `username`, `email`, `password`, `key`, `createdtime`, `updatedtime`, `status`) VALUES
(1, 'arun', 'arun@graphene.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'deactive'),
(2, 'nidhin', 'nidhin@graphene.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'deactive'),
(3, 'anu', 'anu@anu.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sh_user_icons`
--

CREATE TABLE IF NOT EXISTS `sh_user_icons` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) NOT NULL,
  `icon_id` mediumint(8) NOT NULL,
  `key` varchar(255) NOT NULL,
  `status` enum('landscape','launchpad','deleted') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sh_user_icons`
--

